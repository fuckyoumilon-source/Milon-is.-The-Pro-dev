import { upload } from 'https://esm.sh/@vercel/blob@1/client';

const $ = (s) => document.querySelector(s);
const DEFAULT_AVATAR =
  'data:image/svg+xml;utf8,' +
  encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128"><rect width="128" height="128" fill="#3a3b3c"/><circle cx="64" cy="48" r="22" fill="#b0b3b8"/><path d="M20 120c0-26 20-40 44-40s44 14 44 40z" fill="#b0b3b8"/></svg>'
  );

let token = localStorage.getItem('adm') || '';
let state = { profile: {}, songs: [], videos: [] };
let cur = -1;
const audio = new Audio();
audio.preload = 'none';

/* ---------- helpers ---------- */
function toast(msg, ms = 2500) {
  const t = $('#toast');
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(toast.h);
  if (ms) toast.h = setTimeout(() => (t.hidden = true), ms);
}
async function api(path, opts = {}) {
  const r = await fetch(path, {
    ...opts,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: 'Bearer ' + token } : {}),
    },
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) {
    if (r.status === 401 && token) setAdmin('');
    throw new Error(j.error || 'Error ' + r.status);
  }
  return j;
}
const admin = (body) => api('/api/admin', { method: 'POST', body: JSON.stringify(body) });
function el(tag, props = {}, ...kids) {
  const e = document.createElement(tag);
  Object.assign(e, props);
  kids.flat().forEach((k) => e.append(k));
  return e;
}
function fmt(s) {
  if (!isFinite(s)) return '0:00';
  return Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');
}
function setAdmin(t) {
  token = t;
  t ? localStorage.setItem('adm', t) : localStorage.removeItem('adm');
  document.body.classList.toggle('admin', !!t);
  $('#lockBtn').textContent = t ? '🔓' : '🔒';
  if (state.profile.name) render();
}
function pick(accept) {
  return new Promise((res) => {
    const i = el('input', { type: 'file', accept });
    i.onchange = () => res(i.files[0] || null);
    i.click();
  });
}
async function uploadFile(file, folder) {
  const safe = file.name.replace(/[^\w.\-]+/g, '_');
  toast('Upload hocche… 0%', 0);
  const blob = await upload(`${folder}/${safe}`, file, {
    access: 'public',
    handleUploadUrl: '/api/upload',
    clientPayload: token,
    onUploadProgress: ({ percentage }) => toast(`Upload hocche… ${Math.round(percentage)}%`, 0),
  });
  return blob.url;
}
async function run(fn) {
  try {
    await fn();
    toast('Hoye gese ✔');
  } catch (e) {
    toast('Error: ' + e.message, 5000);
  }
}

/* ---------- render ---------- */
function render() {
  const p = state.profile;
  document.title = p.name || 'My Profile';
  $('#navTitle').textContent = p.name || 'My Profile';
  $('#name').textContent = p.name || '';
  $('#bio').textContent = p.bio || '';
  $('#avatar').src = p.avatar || DEFAULT_AVATAR;
  $('#cover').style.backgroundImage = p.cover ? `url("${p.cover}")` : '';
  if (p.callUrl) $('#callBtn').href = p.callUrl;
  $('#callBtn').textContent = '📞 Call ' + (p.phone || '');

  // videos
  const vl = $('#videoList');
  vl.replaceChildren();
  if (!state.videos.length) vl.append(el('div', { className: 'empty card', textContent: 'Ekhono kono video nai' }));
  state.videos.forEach((v) => {
    const video = el('video', { src: v.url, controls: true, preload: 'metadata', playsInline: true });
    video.addEventListener('play', () => audio.pause());
    const head = el(
      'div',
      { className: 'ph' },
      el('img', { src: p.avatar || DEFAULT_AVATAR }),
      el('div', {}, el('b', { textContent: v.title }), el('small', { textContent: new Date(v.createdAt).toLocaleDateString() }))
    );
    if (token) {
      head.append(
        el('button', {
          className: 'btn danger del',
          textContent: '🗑',
          onclick: () => confirm('Video delete korbe?') && run(async () => apply(await admin({ action: 'delete', type: 'video', id: v.id }))),
        })
      );
    }
    vl.append(el('div', { className: 'post' }, head, v.caption ? el('div', { className: 'cap', textContent: v.caption }) : '', video));
  });

  // songs
  const sl = $('#songList');
  sl.replaceChildren();
  if (!state.songs.length) sl.append(el('div', { className: 'empty', textContent: 'Ekhono kono song nai' }));
  state.songs.forEach((s, i) => {
    const row = el(
      'div',
      { className: 'song' + (i === cur ? ' on' : ''), onclick: () => playSong(i) },
      el('div', { className: 'n', textContent: i === cur && !audio.paused ? '🔊' : i + 1 }),
      el('div', { className: 't', textContent: s.title })
    );
    if (token) {
      row.append(
        el('button', {
          className: 'del',
          textContent: '🗑',
          onclick: (e) => {
            e.stopPropagation();
            confirm('Song delete korbe?') && run(async () => apply(await admin({ action: 'delete', type: 'song', id: s.id })));
          },
        })
      );
    }
    sl.append(row);
  });
}
function apply(db) {
  const keepUrl = cur >= 0 ? state.songs[cur]?.url : null;
  state = { profile: { ...state.profile, ...db.profile }, songs: db.songs, videos: db.videos };
  cur = keepUrl ? state.songs.findIndex((s) => s.url === keepUrl) : -1;
  render();
}

/* ---------- player ---------- */
function playSong(i) {
  const s = state.songs[i];
  if (!s) return;
  cur = i;
  audio.pause();
  document.querySelectorAll('video').forEach((v) => v.pause());
  audio.src = s.url;
  audio.play().catch(() => {});
  $('#player').hidden = false;
  $('#pTitle').textContent = s.title;
  render();
  if ('mediaSession' in navigator) {
    navigator.mediaSession.metadata = new MediaMetadata({ title: s.title, artist: state.profile.name || '' });
    navigator.mediaSession.setActionHandler('previoustrack', () => step(-1));
    navigator.mediaSession.setActionHandler('nexttrack', () => step(1));
  }
}
function step(d) {
  if (!state.songs.length) return;
  playSong((cur + d + state.songs.length) % state.songs.length);
}
audio.addEventListener('play', () => ($('#play').textContent = '⏸'));
audio.addEventListener('pause', () => ($('#play').textContent = '▶'));
audio.addEventListener('ended', () => step(1));
audio.addEventListener('timeupdate', () => {
  if (audio.duration) $('#seek').value = (audio.currentTime / audio.duration) * 100;
  $('#pTime').textContent = fmt(audio.currentTime) + ' / ' + fmt(audio.duration);
});
$('#seek').oninput = (e) => audio.duration && (audio.currentTime = (e.target.value / 100) * audio.duration);
$('#play').onclick = () => (audio.paused ? audio.play() : audio.pause());
$('#prev').onclick = () => step(-1);
$('#next').onclick = () => step(1);
$('#closeP').onclick = () => {
  audio.pause();
  $('#player').hidden = true;
};

/* ---------- tabs ---------- */
document.querySelectorAll('.tab').forEach((b) => {
  b.onclick = () => {
    document.querySelectorAll('.tab').forEach((x) => x.classList.toggle('active', x === b));
    document.querySelectorAll('.pane').forEach((p) => (p.hidden = p.id !== b.dataset.tab));
  };
});

/* ---------- login ---------- */
$('#lockBtn').onclick = () => {
  if (token) {
    if (confirm('Logout korbe?')) setAdmin('');
    return;
  }
  $('#loginErr').textContent = '';
  $('#pw').value = '';
  $('#loginModal').hidden = false;
  $('#pw').focus();
};
$('#loginCancel').onclick = () => ($('#loginModal').hidden = true);
async function doLogin() {
  try {
    const r = await api('/api/login', { method: 'POST', body: JSON.stringify({ password: $('#pw').value }) });
    $('#loginModal').hidden = true;
    setAdmin(r.token);
    toast('Admin mode on ✔');
  } catch (e) {
    $('#loginErr').textContent = e.message;
  }
}
$('#loginOk').onclick = doLogin;
$('#pw').onkeydown = (e) => e.key === 'Enter' && doLogin();

/* ---------- admin actions ---------- */
async function changeImage(key) {
  const f = await pick('image/*');
  if (!f) return;
  run(async () => {
    const url = await uploadFile(f, key === 'avatar' ? 'avatars' : 'covers');
    apply(await admin({ action: 'setProfile', [key]: url }));
  });
}
$('#avatarBtn').onclick = () => changeImage('avatar');
$('#coverBtn').onclick = () => changeImage('cover');
$('#avatar').onclick = () => state.profile.avatar && window.open(state.profile.avatar, '_blank');
$('#editBtn').onclick = () => {
  const name = prompt('Naam:', state.profile.name || '');
  if (name === null) return;
  const bio = prompt('Bio:', state.profile.bio || '');
  if (bio === null) return;
  run(async () => apply(await admin({ action: 'setProfile', name, bio })));
};
$('#addSong').onclick = async () => {
  const f = await pick('audio/*');
  if (!f) return;
  const title = prompt('Song-er naam:', f.name.replace(/\.[^.]+$/, ''));
  if (title === null) return;
  run(async () => {
    const url = await uploadFile(f, 'songs');
    apply(await admin({ action: 'addSong', title, url }));
  });
};
$('#addVideo').onclick = async () => {
  const f = await pick('video/*');
  if (!f) return;
  const title = prompt('Video-r naam:', f.name.replace(/\.[^.]+$/, ''));
  if (title === null) return;
  const caption = prompt('Caption (optional):', '') || '';
  run(async () => {
    const url = await uploadFile(f, 'videos');
    apply(await admin({ action: 'addVideo', title, caption, url }));
  });
};

/* ---------- init ---------- */
(async function init() {
  if (token) {
    document.body.classList.add('admin');
    $('#lockBtn').textContent = '🔓';
    fetch('/api/login', { headers: { Authorization: 'Bearer ' + token } }).then((r) => !r.ok && setAdmin(''));
  }
  try {
    const [profile, songs, videos] = await Promise.all([
      fetch('/api/profile').then((r) => r.json()),
      fetch('/api/songs').then((r) => r.json()),
      fetch('/api/videos').then((r) => r.json()),
    ]);
    state = { profile, songs: Array.isArray(songs) ? songs : [], videos: Array.isArray(videos) ? videos : [] };
  } catch (e) {
    toast('Load hoy nai: ' + e.message, 5000);
  }
  render();
})();
