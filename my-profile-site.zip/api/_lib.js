import crypto from 'node:crypto';
import { put, list } from '@vercel/blob';

const DB_PATH = 'db/data.json';
export const PHONE = process.env.PHONE_NUMBER || '01912603270';

const secret = () => process.env.AUTH_SECRET || process.env.ADMIN_PASSWORD || 'change-me';

export function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Cache-Control', 'no-store');
}

const mac = (p) => crypto.createHmac('sha256', secret()).update(p).digest('hex');

export function sign() {
  const p = String(Date.now() + 1000 * 60 * 60 * 24 * 30); // 30 din
  return `${p}.${mac(p)}`;
}

export function verify(t) {
  if (!t || typeof t !== 'string') return false;
  const [p, sig] = t.split('.');
  if (!p || !sig) return false;
  const exp = mac(p);
  if (sig.length !== exp.length) return false;
  if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(exp))) return false;
  return Number(p) > Date.now();
}

export function isAdmin(req) {
  return verify((req.headers.authorization || '').replace(/^Bearer /, ''));
}

const DEFAULT = {
  profile: { name: 'Your Name', bio: '', avatar: '', cover: '' },
  songs: [],
  videos: [],
};

export async function readDB() {
  const { blobs } = await list({ prefix: DB_PATH, limit: 5 });
  const b = blobs.find((x) => x.pathname === DB_PATH);
  if (!b) return structuredClone(DEFAULT);
  const r = await fetch(b.url + '?t=' + Date.now(), { cache: 'no-store' });
  if (!r.ok) return structuredClone(DEFAULT);
  const d = await r.json();
  return {
    ...DEFAULT,
    ...d,
    profile: { ...DEFAULT.profile, ...(d.profile || {}) },
  };
}

export async function writeDB(db) {
  await put(DB_PATH, JSON.stringify(db), {
    access: 'public',
    addRandomSuffix: false,
    allowOverwrite: true,
    contentType: 'application/json',
    cacheControlMaxAge: 60,
  });
}
