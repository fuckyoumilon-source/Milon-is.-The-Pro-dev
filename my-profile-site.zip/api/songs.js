import { cors, readDB } from './_lib.js';

// PUBLIC API: GET /api/songs
export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  try {
    res.json((await readDB()).songs);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}
