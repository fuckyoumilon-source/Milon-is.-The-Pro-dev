import { del } from '@vercel/blob';
import { cors, isAdmin, readDB, writeDB } from './_lib.js';

const clean = (s, n = 200) => String(s || '').slice(0, n);
const isUrl = (u) => /^https:\/\//.test(String(u || ''));
const rid = () => Math.random().toString(36).slice(2, 10);

// Shob change (profile pic, cover, song, video, delete) ekhane. Shudhu admin pare.
export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  if (!isAdmin(req)) return res.status(401).json({ error: 'Unauthorized' });

  try {
    const { action, ...p } = req.body || {};
    const db = await readDB();
    const oldFiles = [];

    if (action === 'setProfile') {
      if ('name' in p) db.profile.name = clean(p.name, 80) || db.profile.name;
      if ('bio' in p) db.profile.bio = clean(p.bio, 300);
      for (const k of ['avatar', 'cover']) {
        if (k in p && isUrl(p[k])) {
          if (db.profile[k] && db.profile[k] !== p[k]) oldFiles.push(db.profile[k]);
          db.profile[k] = p[k];
        }
      }
    } else if (action === 'addSong') {
      if (!isUrl(p.url)) return res.status(400).json({ error: 'url lagbe' });
      db.songs.unshift({ id: rid(), title: clean(p.title, 120) || 'Untitled', url: p.url, createdAt: Date.now() });
    } else if (action === 'addVideo') {
      if (!isUrl(p.url)) return res.status(400).json({ error: 'url lagbe' });
      db.videos.unshift({
        id: rid(),
        title: clean(p.title, 120) || 'Untitled',
        caption: clean(p.caption, 500),
        url: p.url,
        createdAt: Date.now(),
      });
    } else if (action === 'delete') {
      const list = p.type === 'song' ? db.songs : p.type === 'video' ? db.videos : null;
      if (!list) return res.status(400).json({ error: 'type vul' });
      const i = list.findIndex((x) => x.id === p.id);
      if (i >= 0) {
        oldFiles.push(list[i].url);
        list.splice(i, 1);
      }
    } else {
      return res.status(400).json({ error: 'action vul' });
    }

    await writeDB(db);
    // purono file muche felo (storage bachate); fail korle problem nai
    if (oldFiles.length) del(oldFiles).catch(() => {});
    res.json({ ok: true, ...db });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}
