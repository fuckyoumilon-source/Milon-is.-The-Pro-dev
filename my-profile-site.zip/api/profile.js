import { cors, readDB, PHONE } from './_lib.js';

// PUBLIC API: GET /api/profile
export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const db = await readDB();
    res.json({ ...db.profile, phone: PHONE, callUrl: 'tel:' + PHONE.replace(/^0/, '+880') });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}
