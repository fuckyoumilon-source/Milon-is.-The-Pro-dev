import crypto from 'node:crypto';
import { cors, sign, isAdmin } from './_lib.js';

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  // GET = token ager moto valid kina check
  if (req.method === 'GET') {
    return isAdmin(req) ? res.json({ ok: true }) : res.status(401).json({ error: 'Not logged in' });
  }
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const real = process.env.ADMIN_PASSWORD;
  if (!real) return res.status(500).json({ error: 'ADMIN_PASSWORD Vercel env-e set kora nai' });

  const given = String((req.body && req.body.password) || '');
  const a = crypto.createHash('sha256').update(given).digest();
  const b = crypto.createHash('sha256').update(real).digest();
  if (!crypto.timingSafeEqual(a, b)) {
    await new Promise((r) => setTimeout(r, 800));
    return res.status(401).json({ error: 'Password vul' });
  }
  res.json({ token: sign() });
}
