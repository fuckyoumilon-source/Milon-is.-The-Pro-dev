import { handleUpload } from '@vercel/blob/client';
import { cors, verify } from './_lib.js';

// Browser theke sorasori Blob-e upload (boro video/song-er jonno). Shudhu admin pare.
export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const json = await handleUpload({
      body: req.body,
      request: req,
      onBeforeGenerateToken: async (pathname, clientPayload) => {
        if (!verify(clientPayload)) throw new Error('Unauthorized');
        return {
          allowedContentTypes: ['image/*', 'audio/*', 'video/*'],
          addRandomSuffix: true,
          maximumSizeInBytes: 500 * 1024 * 1024,
        };
      },
      onUploadCompleted: async () => {},
    });
    res.json(json);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
}
