# My Profile Site (Dark, Facebook-style)

Features: dark theme, profile + cover, Call button (01912603270), videos, songs with player, public API.
Profile pic / cover / song / video change **shudhu admin (tumi)** pabe. Upload hole Vercel Blob-e permanent thake.

## Vercel-e deploy

1. Ei folder GitHub-e push koro (ba zip unzip kore `vercel` CLI diye deploy koro). Vercel-e Import korle Framework = **Other**, build command khali.
2. Vercel project -> **Storage** -> **Create** -> **Blob** -> project-e connect koro. (eta `BLOB_READ_WRITE_TOKEN` auto set kore)
3. Project -> **Settings -> Environment Variables**:
   - `ADMIN_PASSWORD` = tomar secret password (must)
   - `AUTH_SECRET` = je kono lomba random text (optional, but better)
   - `PHONE_NUMBER` = `01912603270` (optional, default ei number)
4. **Redeploy** koro.
5. Site-e giye uporer dike 🔒 chap -> password dao -> admin mode on. Tarpor 📷 diye pic/cover change, Songs/Videos tab-e add.

## Public API (shobai use korte pare, read-only)

- `GET /api/profile` -> name, bio, avatar, cover, phone, callUrl
- `GET /api/songs`   -> [{ id, title, url, createdAt }]
- `GET /api/videos`  -> [{ id, title, caption, url, createdAt }]

CORS open, tai onno website theke fetch kora jabe. Upload/change/delete kora jay shudhu admin token diye.

## Notes
- Video/song max 500MB (browser theke sorasori Blob-e upload hoy).
- Call button phone-e dialer khole; computer-e dialer app thakle khole.
