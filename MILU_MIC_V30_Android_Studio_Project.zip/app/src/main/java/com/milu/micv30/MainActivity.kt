package com.milu.micv30

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.AudioAttributes
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioManager
import android.media.AudioDeviceInfo
import android.media.AudioTrack.Builder
import android.os.Bundle
import android.widget.*
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : ComponentActivity() {
    @Volatile private var running = false
    @Volatile private var gain = 1.0f
    @Volatile private var bass = 0.0f
    @Volatile private var treble = 0.0f
    private var worker: Thread? = null
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null
    private lateinit var status: TextView
    private lateinit var startButton: Button
    private var bassState = 0.0f
    private var prev = 0.0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.setBackgroundColor(Color.rgb(9, 11, 24))
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 24)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        fun label(text: String, size: Float, color: Int = Color.WHITE): TextView =
            TextView(this).apply { this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER }
        layout.addView(label("MILU MIC V30", 29f, Color.rgb(84, 230, 224)))
        layout.addView(label("LIVE VOICE PROCESSOR", 12f, Color.rgb(193, 139, 255)))
        status = label("MICROPHONE READY", 14f, Color.LTGRAY)
        val statusParams = LinearLayout.LayoutParams(-1, 54).apply { topMargin = 22 }
        layout.addView(status, statusParams)

        startButton = Button(this).apply {
            text = "START LIVE MONITOR"
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.rgb(84, 230, 224))
            setOnClickListener { if (running) stopAudio() else requestAndStart() }
        }
        layout.addView(startButton, LinearLayout.LayoutParams(-1, 54).apply { topMargin = 14; bottomMargin = 20 })

        addSlider(layout, "MIC GAIN", 0, 200, 100) { gain = it / 100f * 2f }
        addSlider(layout, "BASS", -100, 100, 0) { bass = it / 100f }
        addSlider(layout, "TREBLE", -100, 100, 0) { treble = it / 100f }

        layout.addView(label("VOICE PRESETS", 14f, Color.rgb(193, 139, 255)), LinearLayout.LayoutParams(-1, 44))
        val presets = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        listOf("CLEAN", "MEDIUM", "HARD").forEach { name ->
            val b = Button(this).apply {
                text = name
                setOnClickListener {
                    when (name) {
                        "CLEAN" -> { gain = 1f; bass = 0f; treble = 0f }
                        "MEDIUM" -> { gain = 1.15f; bass = 0.25f; treble = 0.08f }
                        else -> { gain = 1.25f; bass = 0.45f; treble = -0.12f }
                    }
                    status.text = "$name PRESET SELECTED — adjust sliders if needed"
                }
            }
            presets.addView(b, LinearLayout.LayoutParams(0, 50, 1f).apply { setMargins(4, 0, 4, 0) })
        }
        layout.addView(presets)
        val note = label("Headphones recommended to reduce feedback.\nThis app processes its own mic audio only.", 12f, Color.LTGRAY)
        layout.addView(note, LinearLayout.LayoutParams(-1, 70).apply { topMargin = 20 })
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun addSlider(parent: LinearLayout, title: String, minV: Int, maxV: Int, initial: Int, change: (Int) -> Unit) {
        val t = TextView(this).apply { text = title; textSize = 13f; setTextColor(Color.WHITE) }
        parent.addView(t)
        val s = SeekBar(this).apply {
            max = maxV - minV
            progress = initial - minV
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { change(progress + minV) }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        parent.addView(s, LinearLayout.LayoutParams(-1, 48))
    }

    private fun requestAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        } else startAudio()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startAudio()
        else status.text = "MICROPHONE PERMISSION REQUIRED"
    }

    private fun startAudio() {
        if (running) return
        val rate = 44100
        val minIn = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val minOut = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minIn <= 0 || minOut <= 0) { status.text = "AUDIO DEVICE NOT SUPPORTED"; return }
        try {
            recorder = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, max(minIn, 4096) * 2)
            player = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(max(minOut, 4096) * 2)
                .setTransferMode(AudioTrack.MODE_STREAM).build()
            recorder?.startRecording()
            player?.play()
            running = true
            startButton.text = "STOP LIVE MONITOR"
            status.text = "LIVE MONITOR ACTIVE"
            worker = thread(name = "MiluAudio") {
                val input = ShortArray(1024)
                val output = ShortArray(1024)
                while (running) {
                    val count = recorder?.read(input, 0, input.size) ?: 0
                    if (count > 0) {
                        for (i in 0 until count) {
                            val x = input[i] / 32768f
                            bassState += 0.08f * (x - bassState)
                            val low = bassState
                            val high = x - low
                            val processed = x * gain + low * bass * 1.8f + high * treble * 1.5f
                            output[i] = (processed.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
                        }
                        player?.write(output, 0, count)
                    }
                }
            }
        } catch (e: Exception) {
            status.text = "AUDIO START FAILED: check mic permission"
            stopAudio()
        }
    }

    private fun stopAudio() {
        running = false
        try { recorder?.stop() } catch (_: Exception) {}
        try { player?.pause(); player?.flush(); player?.stop() } catch (_: Exception) {}
        recorder?.release(); player?.release()
        recorder = null; player = null
        startButton.text = "START LIVE MONITOR"
        status.text = "MICROPHONE READY"
    }

    override fun onDestroy() { stopAudio(); super.onDestroy() }
}
