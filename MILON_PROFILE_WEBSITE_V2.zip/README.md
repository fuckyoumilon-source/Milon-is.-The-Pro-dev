# MILON PROFILE WEBSITE

## Setup on Android
1. Extract this ZIP.
2. Create a GitHub repository and upload all extracted files, OR use Vercel's supported project import flow.
3. In Supabase, open Project Settings → API. Copy the Project URL and anon/public key.
4. In Vercel → Project → Settings → Environment Variables, add:
   - `VITE_SUPABASE_URL` = your Supabase Project URL
   - `VITE_SUPABASE_ANON_KEY` = your Supabase anon/public key
5. Redeploy the project.
6. In Supabase Authentication → Users, ensure the admin account exists and has the same UUID inserted into `public.admin_users`.
7. Sign in on the website using that Supabase user's email and password.

## Important
- Never put the Supabase `service_role` key in this website.
- Do not share your password or API keys in chat.
- The admin UUID configured in SQL must match the authenticated user's UUID.
- The site requires the SQL schema in `supabase_setup.sql`.
- Public profile and songs can be viewed without login; changes require the admin account.
