import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createClient } from '@supabase/supabase-js';
import { Camera, LogIn, LogOut, Music, Save, Settings, UserRound, Upload, Trash2 } from 'lucide-react';
import './style.css';

const url = import.meta.env.VITE_SUPABASE_URL;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = url && key ? createClient(url, key) : null;

function App() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState({display_name:'MILON ISLAM', phone:'', bio:'Welcome to my official profile website.', avatar_url:'', cover_url:''});
  const [songs, setSongs] = useState([]);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [song, setSong] = useState({title:'', artist:'', audio_url:''});
  const [tab, setTab] = useState('profile');

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({data}) => setSession(data.session));
    const {data:{subscription}} = supabase.auth.onAuthStateChange((_event, s) => setSession(s));
    return () => subscription.unsubscribe();
  }, []);

  async function loadData() {
    if (!supabase) return;
    const {data:p} = await supabase.from('profiles').select('*').limit(1).maybeSingle();
    if (p) setProfile(p);
    const {data:s} = await supabase.from('songs').select('*').order('created_at',{ascending:false});
    setSongs(s || []);
  }
  useEffect(() => { loadData(); }, [session]);

  async function login(e) {
    e.preventDefault(); setBusy(true); setMessage('');
    const {error} = await supabase.auth.signInWithPassword({email,password});
    setMessage(error ? error.message : 'Login successful.');
    setBusy(false);
  }
  async function logout() { await supabase.auth.signOut(); }
  async function saveProfile(e) {
    e.preventDefault(); setBusy(true);
    const payload = {...profile, updated_at:new Date().toISOString()};
    delete payload.id;
    const {error} = await supabase.from('profiles').upsert(payload);
    setMessage(error ? error.message : 'Profile saved.');
    setBusy(false); loadData();
  }
  async function uploadImage(e, field) {
    const file = e.target.files?.[0]; if (!file) return;
    if (!file.type.startsWith('image/')) { setMessage('Please select an image file.'); return; }
    if (file.size > 5*1024*1024) { setMessage('Image must be 5 MB or smaller.'); return; }
    const path = `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g,'_')}`;
    const {error} = await supabase.storage.from('profile-media').upload(path,file,{upsert:true});
    if (error) { setMessage(error.message); return; }
    const {data} = supabase.storage.from('profile-media').getPublicUrl(path);
    setProfile(p => ({...p,[field]:data.publicUrl}));
    setMessage('Image uploaded. Save profile to apply it.');
  }
  async function addSong(e) {
    e.preventDefault();
    const {error} = await supabase.from('songs').insert(song);
    setMessage(error ? error.message : 'Song added.');
    if (!error) { setSong({title:'',artist:'',audio_url:''}); loadData(); }
  }
  async function deleteSong(id) {
    const {error} = await supabase.from('songs').delete().eq('id',id);
    setMessage(error ? error.message : 'Song deleted.'); loadData();
  }

  if (!supabase) return <main className="setup"><div className="panel"><h1>MILON ISLAM</h1><h2>Supabase setup needed</h2><p>Add your Supabase Project URL and anon/public key as Vercel environment variables:</p><code>VITE_SUPABASE_URL</code><code>VITE_SUPABASE_ANON_KEY</code><p>Then redeploy the website. Never use the service_role key here.</p></div></main>;

  return <main>
    <header className="top"><a className="brand" href="#">MILON<span> ISLAM</span></a><nav><a href="#home">Home</a><a href="#songs">Songs</a><a href="#admin">Admin</a></nav></header>
    <section id="home" className="hero" style={{backgroundImage:profile.cover_url?`linear-gradient(#09111dcc,#09111dcc),url(${profile.cover_url})`:undefined}}>
      <div className="avatar">{profile.avatar_url?<img src={profile.avatar_url} />:<UserRound size={48}/>}</div>
      <p className="eyebrow">WELCOME TO MY OFFICIAL WEBSITE</p><h1>{profile.display_name || 'MILON ISLAM'}</h1>
      <p className="bio">{profile.bio}</p>
      {profile.phone && <p className="phone">{profile.phone}</p>}
    </section>
    <section id="songs" className="section"><div className="section-title"><div><p className="eyebrow">MY COLLECTION</p><h2>My Songs</h2></div><Music/></div>
      {songs.length ? <div className="songs">{songs.map(s=><article className="song" key={s.id}><Music/><div><b>{s.title}</b><small>{s.artist}</small></div>{s.audio_url && <a href={s.audio_url} target="_blank" rel="noreferrer">Open</a>}</article>)}</div> : <p className="muted">No songs added yet.</p>}
    </section>
    <section id="admin" className="section admin"><div className="section-title"><div><p className="eyebrow">CONTROL CENTER</p><h2>Admin Dashboard</h2></div><Settings/></div>
      {!session ? <form className="login" onSubmit={login}><h3>Admin Login</h3><label>Email<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required/></label><label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required/></label><button disabled={busy}><LogIn size={17}/> {busy?'Please wait':'Login'}</button></form> :
      <><div className="tabs"><button onClick={()=>setTab('profile')} className={tab==='profile'?'active':''}>Profile</button><button onClick={()=>setTab('songs')} className={tab==='songs'?'active':''}>Songs</button><button className="out" onClick={logout}><LogOut size={16}/> Logout</button></div>
      {tab==='profile' ? <form className="editor" onSubmit={saveProfile}><label>Display name<input value={profile.display_name||''} onChange={e=>setProfile({...profile,display_name:e.target.value})}/></label><label>Phone<input value={profile.phone||''} onChange={e=>setProfile({...profile,phone:e.target.value})}/></label><label>Bio<textarea value={profile.bio||''} onChange={e=>setProfile({...profile,bio:e.target.value})}/></label><div className="upload-row"><label className="upload"><Camera/> Profile photo<input type="file" accept="image/*" onChange={e=>uploadImage(e,'avatar_url')}/></label><label className="upload"><Upload/> Cover photo<input type="file" accept="image/*" onChange={e=>uploadImage(e,'cover_url')}/></label></div><button disabled={busy}><Save size={17}/> Save Profile</button></form> :
      <><form className="editor" onSubmit={addSong}><label>Song title<input value={song.title} onChange={e=>setSong({...song,title:e.target.value})} required/></label><label>Artist<input value={song.artist} onChange={e=>setSong({...song,artist:e.target.value})}/></label><label>Audio URL<input type="url" placeholder="https://..." value={song.audio_url} onChange={e=>setSong({...song,audio_url:e.target.value})}/></label><button><Music size={17}/> Add Song</button></form>{songs.map(s=><div className="song" key={s.id}><div><b>{s.title}</b><small>{s.artist}</small></div><button className="danger" onClick={()=>deleteSong(s.id)}><Trash2 size={16}/></button></div>)}</>}
      </>}
      {message && <p className="message">{message}</p>}
    </section>
    <footer>© {new Date().getFullYear()} MILON ISLAM · All rights reserved</footer>
  </main>;
}
createRoot(document.getElementById('root')).render(<App />);
