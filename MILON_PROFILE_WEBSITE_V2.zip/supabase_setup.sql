-- MILON PROFILE WEBSITE schema
-- Replace the UUID below with your actual Supabase Auth user UUID.
create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz default now()
);
alter table public.admin_users enable row level security;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = ''
as $$
  select exists (select 1 from public.admin_users where user_id = (select auth.uid()));
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

create table if not exists public.profiles (
  id uuid primary key default gen_random_uuid(),
  display_name text,
  phone text,
  bio text,
  avatar_url text,
  cover_url text,
  updated_at timestamptz default now()
);
create table if not exists public.site_settings (
  setting_key text primary key,
  setting_value jsonb,
  updated_at timestamptz default now()
);
create table if not exists public.songs (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  artist text,
  audio_url text,
  cover_url text,
  created_at timestamptz default now()
);

alter table public.profiles enable row level security;
alter table public.site_settings enable row level security;
alter table public.songs enable row level security;

grant select on public.profiles, public.site_settings, public.songs to anon, authenticated;
grant insert, update, delete on public.profiles, public.site_settings, public.songs to authenticated;

drop policy if exists "profile_public_read" on public.profiles;
drop policy if exists "profile_admin_all" on public.profiles;
create policy "profile_public_read" on public.profiles for select to anon, authenticated using (true);
create policy "profile_admin_all" on public.profiles for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "settings_public_read" on public.site_settings;
drop policy if exists "settings_admin_all" on public.site_settings;
create policy "settings_public_read" on public.site_settings for select to anon, authenticated using (true);
create policy "settings_admin_all" on public.site_settings for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "songs_public_read" on public.songs;
drop policy if exists "songs_admin_all" on public.songs;
create policy "songs_public_read" on public.songs for select to anon, authenticated using (true);
create policy "songs_admin_all" on public.songs for all to authenticated using (public.is_admin()) with check (public.is_admin());

insert into storage.buckets (id, name, public)
values ('profile-media', 'profile-media', true)
on conflict (id) do update set public = true;

drop policy if exists "profile_media_public_read" on storage.objects;
drop policy if exists "profile_media_admin_insert" on storage.objects;
drop policy if exists "profile_media_admin_update" on storage.objects;
drop policy if exists "profile_media_admin_delete" on storage.objects;
create policy "profile_media_public_read" on storage.objects for select to anon, authenticated using (bucket_id = 'profile-media');
create policy "profile_media_admin_insert" on storage.objects for insert to authenticated with check (bucket_id = 'profile-media' and public.is_admin());
create policy "profile_media_admin_update" on storage.objects for update to authenticated using (bucket_id = 'profile-media' and public.is_admin()) with check (bucket_id = 'profile-media' and public.is_admin());
create policy "profile_media_admin_delete" on storage.objects for delete to authenticated using (bucket_id = 'profile-media' and public.is_admin());

-- Register your admin after confirming the Auth user exists:
-- insert into public.admin_users(user_id) values ('YOUR-AUTH-USER-UUID') on conflict do nothing;
